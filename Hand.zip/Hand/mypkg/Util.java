package mypkg;
import javax.swing.*;
public class Util
{
	public static void display(String a)
	{	
		JOptionPane.showMessageDialog(null,a);
	}
	public static int iInput(String a)
	{
		int no=0;
		try
		{
			no=Integer.parseInt(JOptionPane.showInputDialog(null,a));
		}
		catch(Exception e){}
		return no;
	}
	public static double dInput(String a)
	{
		double no=0.0;
		try
		{
			no=Double.parseDouble(JOptionPane.showInputDialog(null,a));
		}
		catch(Exception e){}
		return no;
	}
	public static String sInput(String a)
	{
		String nm=JOptionPane.showInputDialog(null,a);
		return nm;
	}
	public static int oInput(String title,String[]choice)
	{
		int opt=JOptionPane.showOptionDialog(null,"Choose Option",title,JOptionPane.YES_OPTION,JOptionPane.INFORMATION_MESSAGE,null,choice,0);
		return opt;
	}
}
