import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.io.*;
import java.awt.image.BufferedImage;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.script.*;
import mypkg.Util;

class HandwrittenTextRecogniser extends JFrame implements ActionListener
{
	JPanel p,panelimage;
	JButton btrain,bvalid,bbeams,bsetimg,bgetimgpth;
	Box box;
	BufferedImage image;
	JLabel jlabel;
	
	HandwrittenTextRecogniser()
	{
		super("Handwritten Text Recogniser");
		getContentPane().setBackground(Color.WHITE);
		
		btrain = new JButton("TRAIN");
		bvalid = new JButton("VALIDATE");
		bbeams = new JButton("BEAM SEARCH");
		bsetimg = new JButton("SET IMAGE");
		bgetimgpth = new JButton("IMAGE PATH");
		
		Border line =new LineBorder(Color.BLACK);
		Border margin =new EmptyBorder(5,5,5,5);
		Border compound = new CompoundBorder(line,margin);
		
		btrain.setForeground(Color.BLACK);
		btrain.setBackground(Color.WHITE);
		btrain.setBorder(compound);
		btrain.setFont(new Font("Arial",Font.PLAIN,20));

		bvalid.setForeground(Color.BLACK);
		bvalid.setBackground(Color.WHITE);
		bvalid.setBorder(compound);
		bvalid.setFont(new Font("Arial",Font.PLAIN,20));
		
		bbeams.setForeground(Color.BLACK);
		bbeams.setBackground(Color.WHITE);
		bbeams.setBorder(compound);
		bbeams.setFont(new Font("Arial",Font.PLAIN,20));
		
		bsetimg.setForeground(Color.BLACK);
		bsetimg.setBackground(Color.WHITE);
		bsetimg.setBorder(compound);
		bsetimg.setFont(new Font("Arial",Font.PLAIN,20));
		
		bgetimgpth.setForeground(Color.BLACK);
		bgetimgpth.setBackground(Color.WHITE);
		bgetimgpth.setBorder(compound);
		bgetimgpth.setFont(new Font("Arial",Font.PLAIN,20));

		btrain.addActionListener(this);
		bvalid.addActionListener(this);
		bbeams.addActionListener(this);
		bsetimg.addActionListener(this);
		bgetimgpth.addActionListener(this);
	
		p = new JPanel();
		p.setBackground(Color.WHITE);
		p.setLayout(new GridLayout(5,1,0,10));
		p.add(btrain);
		p.add(bvalid);
		p.add(bbeams);
		p.add(bsetimg);
		p.add(bgetimgpth);
		//p.add(box);
		JPanel p1 = new JPanel();
		p1.setBackground(Color.WHITE);
		panelimage = new JPanel();
		try
		{
			//image = ImageIO.read(new File("doc/htr.png"));
			jlabel = new JLabel("Image will be displayed Here");

		}catch(Exception e){}
		panelimage.setBackground(Color.WHITE);
		p1.add(p);
		panelimage.add(jlabel);
		add(p1, "West");
		add(panelimage, "East");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(600,300);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e)
	{
		int opt = 0;
		JButton b = (JButton)e.getSource();
		try
		{
			createFiles();
		}catch(Exception e1){}

		if(b == bsetimg)
		{
			setImage();
			predictImage();

		}
		
		if(b == btrain)
		{
			try
			{
				//trainImage2();
				opt = JOptionPane.showConfirmDialog(null,"Are you Sure you want proceed \n by proceeding you'll be deleteing previous model","Confirm",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.WARNING_MESSAGE);
				if(opt == 0)
				{
					//deleteModel();
					Util.display("Files Deleted Successfully");
				}
				
				//trainImage();
			}catch(Exception e1){}
			if(opt == 0)
				btrain.setEnabled(false);
		}

		if(b == bgetimgpth)
			Util.display("Image Path $ "+getPath());
	}

	private void setImage()
	{
		File file = null;
		JFileChooser fc = new JFileChooser();
		FileOutputStream fos;
		int i = fc.showOpenDialog(this);
		String path = "";
		if(i == JFileChooser.APPROVE_OPTION)
		{
			file = fc.getSelectedFile();
			path = file.getPath();
		}
		try
			{
				image = ImageIO.read(file);
				jlabel.setText("");
				jlabel.setIcon(new ImageIcon(image));
				fos = new FileOutputStream("src/path.dat");
				byte b[] = path.getBytes();
				fos.write(b);
				fos.close();
			}catch(Exception e1){}
	}

	public String getPath()
	{
		try
		{
			BufferedReader reader = new BufferedReader(new FileReader("src/path.dat"));
			return reader.readLine();
		}catch(Exception e1){return null;}
	}

	private void predictImage()
	{
		Process p;
		try
		{
			String [] cmd = {"sh","src/printPred.sh"};
			p = Runtime.getRuntime().exec(cmd);
			p.waitFor();
			BufferedReader reader = new BufferedReader(new FileReader("src/op.txt"));
			String line;
			while((line = reader.readLine())!=null)
			{
				System.out.println(line);
			}
			reader.close();
		}catch(Exception e1){}
	}

	private void createFiles() throws Exception
	{
		FileOutputStream fos = new FileOutputStream("src/train.sh");
		String a = "python main.py --train";
		byte b[] = a.getBytes();
		fos.write(b);
		fos.close();
		fos = new FileOutputStream("src/op.txt");
		fos = new FileOutputStream("src/printTrain.sh");
		a = "./train.sh >> op.txt";
		b = a.getBytes();
		fos.write(b);
		fos.close();
		fos = new FileOutputStream("src/pred.sh");
		a = "python main.py";
		fos.write(a.getBytes());
		fos.close();
		fos = new FileOutputStream("src/printPred.sh");
		a = "./pred.sh >> op.txt";
		fos.write(a.getBytes());
		fos.close();
		fos = new FileOutputStream("model/delete.sh");
		a = "";
	}

	private void trainImage()
	{
		Process p;
		try
		{
			String [] cmd = {"sh","src/printTrain.sh"};
			p = Runtime.getRuntime().exec(cmd);
			p.waitFor();
			BufferedReader reader = new BufferedReader(new FileReader("src/op.txt"));
			String line;
			while((line =reader.readLine())!=null)
			{
				System.out.println(line);
			}
			reader.close();
		}catch(Exception e1){}
	}

	private void deleteModel()
	{
		Process p;
		try
		{
			String [] cmd = {"sh","model/delete.sh"};
			p = Runtime.getRuntime().exec(cmd);
			p.waitFor();
			BufferedReader reader = new BufferedReader(new FileReader("model/op.txt"));
			String line;
			while((line =reader.readLine())!=null)
			{
				System.out.println(line);
			}
			reader.close();
		}catch(Exception e1){}
	}

	public static void main(String [] args)
	{
		HandwrittenTextRecogniser a = new HandwrittenTextRecogniser();
	}
}